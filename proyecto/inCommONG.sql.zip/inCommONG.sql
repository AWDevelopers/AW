-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 03-05-2016 a las 17:54:56
-- Versión del servidor: 10.1.10-MariaDB
-- Versión de PHP: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inCommONG`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `idProducto` int(10) NOT NULL,
  `CIFOng` varchar(9) NOT NULL,
  `DNIUsuario` varchar(9) NOT NULL,
  `numProductos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Donaciones`
--

CREATE TABLE `Donaciones` (
  `DNIUsuario` varchar(9) NOT NULL,
  `idProyecto` int(10) NOT NULL,
  `donacion` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Noticia`
--

CREATE TABLE `Noticia` (
  `id` int(10) NOT NULL,
  `titulo` varchar(20) NOT NULL,
  `tipo` enum('primaria','secundaria','terciaria','otra') NOT NULL,
  `descripcionCorta` text,
  `descripcionLarga` text NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ONG`
--

CREATE TABLE `ONG` (
  `CIF` varchar(9) NOT NULL,
  `nombre` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `telefono` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Producto`
--

CREATE TABLE `Producto` (
  `idProducto` int(10) NOT NULL,
  `CIFOng` varchar(9) NOT NULL,
  `stock` int(11) DEFAULT NULL,
  `precio` int(11) DEFAULT NULL,
  `nombre` varchar(20) NOT NULL,
  `descripcionCorta` text,
  `descripcionLarga` text NOT NULL,
  `imagen` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Proyecto`
--

CREATE TABLE `Proyecto` (
  `idProyecto` int(10) NOT NULL,
  `CIFOng` varchar(9) NOT NULL,
  `fechaCreacion` date NOT NULL,
  `dineroNecesario` float NOT NULL,
  `dineroAcumulado` float DEFAULT NULL,
  `nombre` varchar(20) NOT NULL,
  `descripcionLarga` text NOT NULL,
  `descripcionCorta` text,
  `imagen` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuario`
--

CREATE TABLE `Usuario` (
  `DNI` varchar(9) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `cp` int(10) DEFAULT NULL,
  `usuario` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `avatar` blob,
  `sexo` enum('Masculino','Femenino','','') NOT NULL,
  `telefono` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `voluntarios`
--

CREATE TABLE `voluntarios` (
  `idProyecto` int(10) NOT NULL,
  `DNIUsuario` varchar(9) NOT NULL,
  `dia` date NOT NULL,
  `horaEntrada` time NOT NULL,
  `horaSalida` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`idProducto`,`CIFOng`,`DNIUsuario`),
  ADD KEY `DNIUsuario` (`DNIUsuario`),
  ADD KEY `CIFOng` (`CIFOng`);

--
-- Indices de la tabla `Donaciones`
--
ALTER TABLE `Donaciones`
  ADD PRIMARY KEY (`DNIUsuario`,`idProyecto`),
  ADD KEY `idProyecto` (`idProyecto`);

--
-- Indices de la tabla `Noticia`
--
ALTER TABLE `Noticia`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `ONG`
--
ALTER TABLE `ONG`
  ADD PRIMARY KEY (`CIF`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `CIF` (`CIF`);

--
-- Indices de la tabla `Producto`
--
ALTER TABLE `Producto`
  ADD PRIMARY KEY (`idProducto`,`CIFOng`),
  ADD UNIQUE KEY `idProducto` (`idProducto`,`CIFOng`),
  ADD KEY `CIFOng` (`CIFOng`);

--
-- Indices de la tabla `Proyecto`
--
ALTER TABLE `Proyecto`
  ADD PRIMARY KEY (`idProyecto`,`CIFOng`),
  ADD UNIQUE KEY `idProyecto` (`idProyecto`,`CIFOng`),
  ADD KEY `CIFOng` (`CIFOng`);

--
-- Indices de la tabla `Usuario`
--
ALTER TABLE `Usuario`
  ADD PRIMARY KEY (`DNI`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `DNI` (`DNI`);

--
-- Indices de la tabla `voluntarios`
--
ALTER TABLE `voluntarios`
  ADD PRIMARY KEY (`idProyecto`,`DNIUsuario`),
  ADD KEY `DNIUsuario` (`DNIUsuario`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`DNIUsuario`) REFERENCES `Usuario` (`DNI`),
  ADD CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`CIFOng`) REFERENCES `ONG` (`CIF`),
  ADD CONSTRAINT `compras_ibfk_3` FOREIGN KEY (`idProducto`) REFERENCES `Producto` (`idProducto`);

--
-- Filtros para la tabla `Donaciones`
--
ALTER TABLE `Donaciones`
  ADD CONSTRAINT `Donaciones_ibfk_1` FOREIGN KEY (`DNIUsuario`) REFERENCES `Usuario` (`DNI`),
  ADD CONSTRAINT `Donaciones_ibfk_2` FOREIGN KEY (`idProyecto`) REFERENCES `Proyecto` (`idProyecto`);

--
-- Filtros para la tabla `Producto`
--
ALTER TABLE `Producto`
  ADD CONSTRAINT `Producto_ibfk_1` FOREIGN KEY (`CIFOng`) REFERENCES `Proyecto` (`CIFOng`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `Proyecto`
--
ALTER TABLE `Proyecto`
  ADD CONSTRAINT `Proyecto_ibfk_1` FOREIGN KEY (`CIFOng`) REFERENCES `ONG` (`CIF`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `voluntarios`
--
ALTER TABLE `voluntarios`
  ADD CONSTRAINT `voluntarios_ibfk_1` FOREIGN KEY (`idProyecto`) REFERENCES `Proyecto` (`idProyecto`),
  ADD CONSTRAINT `voluntarios_ibfk_2` FOREIGN KEY (`DNIUsuario`) REFERENCES `Usuario` (`DNI`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
